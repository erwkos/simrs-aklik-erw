from django.core.exceptions import ValidationError


def validation_data_klaim(register, data_klaim):
    pass
